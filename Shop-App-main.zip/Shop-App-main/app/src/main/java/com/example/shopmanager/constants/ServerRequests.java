package com.example.shopmanager.constants;

public enum ServerRequests {
    addAccount,
    addProduct,
    getProducts,
    deleteProduct,
    getIds
}
